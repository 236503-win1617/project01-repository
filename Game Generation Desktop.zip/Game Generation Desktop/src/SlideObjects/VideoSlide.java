package SlideObjects;

/**
 * Created by Evgeniy on 11/26/2015.
 */
public class VideoSlide extends AbstractSlide
{
    @Override
    public SlideType getType() {
        return SlideType.Video;
    }
}
