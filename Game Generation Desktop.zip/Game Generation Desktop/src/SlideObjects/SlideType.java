package SlideObjects;

/**
 * Created by Evgeniy on 3/19/2016.
 */
public enum SlideType {
    Picture,
    Video,
    Game
}
