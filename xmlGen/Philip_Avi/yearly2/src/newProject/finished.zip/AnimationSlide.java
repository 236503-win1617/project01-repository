package newProject;

/**
 * Created by Evgeniy on 11/26/2015.
 */
public class AnimationSlide extends AbstractSlide
{
}
