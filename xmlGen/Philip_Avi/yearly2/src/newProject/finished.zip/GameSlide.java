package newProject;
/**
 * Created by Evgeniy on 11/26/2015.
 */
public class GameSlide
{
    //TODO: should be implemented much later
}
